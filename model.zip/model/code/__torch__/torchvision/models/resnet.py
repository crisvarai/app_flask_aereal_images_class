class ResNet(Module):
  __parameters__ = []
  __buffers__ = []
  training : bool
  _is_full_backward_hook : Optional[bool]
  inplanes : int
  dilation : int
  groups : int
  base_width : int
  conv1 : __torch__.torch.nn.modules.conv.Conv2d
  bn1 : __torch__.torch.nn.modules.batchnorm.BatchNorm2d
  relu : __torch__.torch.nn.modules.activation.ReLU
  maxpool : __torch__.torch.nn.modules.pooling.MaxPool2d
  layer1 : __torch__.torch.nn.modules.container.Sequential
  layer2 : __torch__.torch.nn.modules.container.___torch_mangle_8.Sequential
  layer3 : __torch__.torch.nn.modules.container.___torch_mangle_16.Sequential
  layer4 : __torch__.torch.nn.modules.container.___torch_mangle_24.Sequential
  avgpool : __torch__.torch.nn.modules.pooling.AdaptiveAvgPool2d
  fc : __torch__.torch.nn.modules.linear.Linear
  def forward(self: __torch__.torchvision.models.resnet.ResNet,
    x: Tensor) -> Tensor:
    return (self)._forward_impl(x, )
  def _forward_impl(self: __torch__.torchvision.models.resnet.ResNet,
    x: Tensor) -> Tensor:
    conv1 = self.conv1
    x0 = (conv1).forward(x, )
    bn1 = self.bn1
    x1 = (bn1).forward(x0, )
    relu = self.relu
    x2 = (relu).forward(x1, )
    maxpool = self.maxpool
    x3 = (maxpool).forward(x2, )
    layer1 = self.layer1
    x4 = (layer1).forward(x3, )
    layer2 = self.layer2
    x5 = (layer2).forward(x4, )
    layer3 = self.layer3
    x6 = (layer3).forward(x5, )
    layer4 = self.layer4
    x7 = (layer4).forward(x6, )
    avgpool = self.avgpool
    x8 = (avgpool).forward(x7, )
    x9 = torch.flatten(x8, 1)
    fc = self.fc
    return (fc).forward(x9, )
class BasicBlock(Module):
  __parameters__ = []
  __buffers__ = []
  training : bool
  _is_full_backward_hook : NoneType
  downsample : NoneType
  stride : int
  conv1 : __torch__.torch.nn.modules.conv.___torch_mangle_0.Conv2d
  bn1 : __torch__.torch.nn.modules.batchnorm.BatchNorm2d
  relu : __torch__.torch.nn.modules.activation.ReLU
  conv2 : __torch__.torch.nn.modules.conv.___torch_mangle_0.Conv2d
  bn2 : __torch__.torch.nn.modules.batchnorm.BatchNorm2d
  def forward(self: __torch__.torchvision.models.resnet.BasicBlock,
    x: Tensor) -> Tensor:
    conv1 = self.conv1
    out = (conv1).forward(x, )
    bn1 = self.bn1
    out0 = (bn1).forward(out, )
    relu = self.relu
    out1 = (relu).forward(out0, )
    conv2 = self.conv2
    out2 = (conv2).forward(out1, )
    bn2 = self.bn2
    out3 = (bn2).forward(out2, )
    out4 = torch.add_(out3, x)
    relu0 = self.relu
    return (relu0).forward(out4, )
