class Model(Module):
  __parameters__ = []
  __buffers__ = []
  training : bool
  _is_full_backward_hook : Optional[bool]
  labels : List[str]
  resnet : __torch__.torchvision.models.resnet.ResNet
  def forward(self: __torch__.Model,
    x: Tensor) -> Tensor:
    resnet = self.resnet
    return (resnet).forward(x, )
